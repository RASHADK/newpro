from django.shortcuts import render,redirect
from django.views.generic import View
from .forms import *
from django.http import HttpResponse
from django.contrib import messages
from .models import StudentModel
from django.utils.decorators import method_decorator
# Create your views here.

def signin_required(fun):
    def wrapper(request,*args,**kwargs):
        if request.user.is_authenticated:
            return fun(request,*args,**kwargs)
        else:
            return redirect("log")
    return wrapper            

@method_decorator(signin_required,name='dispatch')
class AddMarkView(View):
    def get(self,request,*args,**kwargs):
        f=AddmarkForm()
        return render(request,"addmark.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=AddmarkForm(data=request.POST)
        if form_data.is_valid():  
           m1=form_data.cleaned_data.get("mark1")
           m2=form_data.cleaned_data.get("mark2")
           m3=form_data.cleaned_data.get("mark3")
           m4=form_data.cleaned_data.get("mark4")
           m5=form_data.cleaned_data.get("mark5")
           mark=int(m1)+int(m2)+int(m3)+int(m4)+int(m5)
           return render(request,"addmark.html",{"data":mark})
        else:
            return render(request,"addmark.html",{"form":form_data})   
# class AddStudentView(View):
#     def get(self,request,*args,**kwargs):
#         f=StudentForm()
#         return render(request,"addstu.html",{"form":f})
#     def post(self,request,*args,**kwargs):
#         form_data=StudentForm(data=request.POST)
#         if form_data.is_valid():
#           first_name=(form_data.cleaned_data.get("first_name"))
#           last_name=(form_data.cleaned_data.get("last_name"))
#           age=(form_data.cleaned_data.get("age"))
#           address=(form_data.cleaned_data.get("address"))
#           email=(form_data.cleaned_data.get("email"))
#           phone=(form_data.cleaned_data.get("phone"))
#           StudentModel.objects.create(first=first_name,last=last_name,age=age,address=address,phone=phone,email=email)
#           messages.success(request,"Student added successfully!!!")  
#           return redirect("h")  
#         else:
#             messages.error(request,"Student adding Failed!!!")
#             return render(request,"addstu.html",{"form":form_data}) 

class AddStudentMView(View):
     def get(self,request,*args,**kwargs):
         f=StudentMform()
         return render(request,"addstu.html",{"form":f})
     def post(self,request,*args,**kwargs):
         form_data=StudentMform(data=request.POST,files=request.FILES)
         if form_data.is_valid():
            form_data.save()
            messages.success(request,"Student added successfully!!!")  
            return redirect("h")  
         else:
             messages.error(request,"Student adding Failed!!!")
             return render(request,"addstu.html",{"form":form_data}) 



@method_decorator(signin_required,name='dispatch')
class StudentListView(View):
    def get(self,request,*args,**kwargs):
        if request.user.is_authenticated:
          res=StudentModel.objects.all()
          return render(request,"studentlist.html",{"data":res})
        else:
            return redirect("log")  
@method_decorator(signin_required,name='dispatch')
class StudentDeleteView(View):
    def get(self,request,*args,**kwargs):
       sid=kwargs.get("ssid")
       stu=StudentModel.objects.get(id=sid)
       stu.delete()
       return redirect("viewstudent")

# class StudentEditView(View):
#     def get(self,request,*args,**kwargs):
#         id=kwargs.get("sid")
#         stu=StudentModel.objects.get(id=id)
#         f=StudentForm(initial={"first_name":stu.first,"last_name":stu.last,"age":stu.age,"address":stu.address,"email":stu.email,"phone":stu.phone})
#         return render(request,"editstudent.html",{"form":f})       
#     def post(self,request,*args,**kwargs):
#         form_data=StudentForm(data=request.POST)
#         if form_data.is_valid():
#           first_name=(form_data.cleaned_data.get("first_name"))
#           last_name=(form_data.cleaned_data.get("last_name"))
#           age=(form_data.cleaned_data.get("age"))
#           address=(form_data.cleaned_data.get("address"))
#           email=(form_data.cleaned_data.get("email"))
#           phone=(form_data.cleaned_data.get("phone"))
#           id=kwargs.get("sid")
#           stu=StudentModel.objects.get(id=id)
#           stu.first=first_name
#           stu.last=last_name
#           stu.age=age
#           stu.address=address
#           stu.email=email
#           stu.phone=phone
#           stu.save()
#           messages.success(request,"Student-Detais Updated successfully!!!")  
#           return redirect("viewstudent")
#         else:
#           messages.success(request,"Update Failed!!!")  
#           return render(request,"editstudent.html",{"form":form_data})  
@method_decorator(signin_required,name='dispatch')
class StudentEditMView(View):
    def get(self,request,*args,**kwargs):
         id=kwargs.get("sid")
         stu=StudentModel.objects.get(id=id)
         f=StudentMform(instance=stu)
         return  render(request,"editstudent.html",{"form":f})
    def post(self,request,*args,**kwargs):
        id=kwargs.get("sid")
        stu=StudentModel.objects.get(id=id)
        form_data=StudentMform(data=request.POST,instance=stu,files=request.FILES)
        if form_data.is_valid():
            form_data.save()
            messages.success(request,"Student-Detais Updated successfully!!!")  
            return redirect("viewstudent")
        else:
           messages.success(request,"Update Failed!!!")  
           return render(request,"editstudent.html",{"form":form_data})  
