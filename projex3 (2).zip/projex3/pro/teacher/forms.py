from django import forms
from .models import StudentModel

class AddmarkForm(forms.Form):
    mark1=forms.IntegerField(label="Enter Mark of subject1")
    mark2=forms.IntegerField(label="Enter Mark of subject2") 
    mark3=forms.IntegerField(label="Enter Mark of subject3")
    mark4=forms.IntegerField(label="Enter Mark of subject4")
    mark5=forms.IntegerField(label="Enter Mark of subject5")
    def clean(self) :
        cleaned_data=super().clean()
        m1=cleaned_data.get("mark1")
        m2=cleaned_data.get("mark2")
        m3=cleaned_data.get("mark3")
        m4=cleaned_data.get("mark4")
        m5=cleaned_data.get("mark5")
        if m1<0:
            msg="mark less than zero.Invalid Input"
            self.add_error("mark1",msg)
        if m2<0:
            msg="mark less than zero.Invalid Input"
            self.add_error("mark2",msg) 
        if m3<0:
            msg="mark less than zero.Invalid Input"
            self.add_error("mark3",msg) 
        if m4<0:
            msg="mark less than zero.Invalid Input"
            self.add_error("mark4",msg) 
        if m5<0:
            msg="mark less than zero.Invalid Input"
            self.add_error("mark5",msg)               
                

             
class StudentForm(forms.Form):
    first_name=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"Enter your first name"}))
    last_name=forms.CharField(max_length=100,widget=forms.TextInput(attrs={"class":"form-control","placeholder":"Enter your last name"}))
    age=forms.IntegerField(widget=forms.NumberInput(attrs={"class":"form-control","placeholder":"Enter your age"}))
    address=forms.CharField(max_length=500,widget=forms.Textarea(attrs={"class":"form-control","placeholder":"Enter your address"}))
    email=forms.EmailField(widget=forms.EmailInput(attrs={"class":"form-control","placeholder":"Enter your Email"}))
    phone=forms.IntegerField(widget=forms.NumberInput(attrs={"class":"form-control","placeholder":"Enter your phone"}))
    def clean(self):
        cleaned_data=super().clean()
        first_name=cleaned_data.get("first_name")
        last_name=cleaned_data.get("last_name")
        age=cleaned_data.get("age")
        address=cleaned_data.get("address")
        email=cleaned_data.get("email")
        phone=str(cleaned_data.get("phone"))
        if first_name==last_name:
            msg="name is same"
            self.add_error("first_name",msg)
        if age<=1:  
            msg="age is less than zero"
            self.add_error("age",msg)
        if len(phone)!=10:
            msg="number are not  10"
            self.add_error("phone",msg) 
class StudentMform(forms.ModelForm):
    class Meta:
        model=StudentModel
        fields="__all__"
        widgets={
            "first":forms.TextInput(attrs={"class":"form-control","placeholder":"first name"}),
            "last":forms.TextInput(attrs={"class":"form-control","placeholder":"last name"}),
            "age":forms.NumberInput(attrs={"class":"form-control","placeholder":"age"}),
            "address":forms.Textarea(attrs={"class":"form-control","placeholder":"address"}),
            "phone":forms.NumberInput(attrs={"class":"form-control","placeholder":"phone"}),
            "email":forms.EmailInput(attrs={"class":"form-control","placeholder":"email"}),
        }
    def clean(self):
        cleaned_data=super().clean()
        first_name=cleaned_data.get("first")
        last_name=cleaned_data.get("last")
        age=cleaned_data.get("age")
        address=cleaned_data.get("address")
        email=cleaned_data.get("email")
        phone=str(cleaned_data.get("phone"))
        if first_name==last_name:
            msg="name is same"
            self.add_error("last",msg)
        if age<=1:  
            msg="age is less than zero"
            self.add_error("age",msg)
        if len(phone)!=10:
            msg="number are not  10"
            self.add_error("phone",msg) 
