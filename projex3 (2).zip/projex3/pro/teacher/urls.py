from django.urls import path
from.views import *
urlpatterns=[
    path('addmark/',AddMarkView.as_view(),name="add"),
    path('addst/',AddStudentMView.as_view(),name="addstudent"),
    path('studentlist/',StudentListView.as_view(),name="viewstudent"),
    path('dellist/<int:ssid>',StudentDeleteView.as_view(),name="delstu"),
    path('editist/<int:sid>',StudentEditMView.as_view(),name="edtstu")
    

]