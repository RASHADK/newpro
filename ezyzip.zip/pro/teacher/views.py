from django.shortcuts import render
from django.views.generic import View
from .forms import AddmarkForm,StudentForm
from django.http import HttpResponse
# Create your views here.

class AddMarkView(View):
    def get(self,request,*args,**kwargs):
        f=AddmarkForm()
        return render(request,"addmark.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=AddmarkForm(data=request.POST)
        if form_data.is_valid():  
           m1=form_data.cleaned_data.get("mark1")
           m2=form_data.cleaned_data.get("mark2")
           m3=form_data.cleaned_data.get("mark3")
           m4=form_data.cleaned_data.get("mark4")
           m5=form_data.cleaned_data.get("mark5")
           mark=int(m1)+int(m2)+int(m3)+int(m4)+int(m5)
           return render(request,"addmark.html",{"data":mark})
        else:
            return render(request,"addmark.html",{"form":form_data})   
class AddStudentView(View):
    def get(self,request,*args,**kwargs):
        f=StudentForm()
        return render(request,"addstu.html",{"form":f})
    def post(self,request,*args,**kwargs):
        form_data=StudentForm(data=request.POST)
        if form_data.is_valid():
           return HttpResponse("first_name:"+form_data.cleaned_data.get("first_name")+"<br>last_name:"+form_data.cleaned_data.get("last_name")+"<br>age:"+form_data.cleaned_data.get("age")+"<br>address:"+form_data.cleaned_data.get("address")+"<br>email:"+form_data.cleaned_data.get("email")+"<br>phone:"+form_data.cleaned_data.get("phone"))    
        else:
            return render(request,"addstu.html",{"form":form_data}) 