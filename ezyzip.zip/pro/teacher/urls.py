from django.urls import path
from.views import AddMarkView,AddStudentView
urlpatterns=[
    path('addmark/',AddMarkView.as_view(),name="add"),
    path('addst/',AddStudentView.as_view(),name="addstudent")

]