from django.shortcuts import render
from django.views.generic import View
from .forms import LoginForm,RegForm
from django.http import HttpResponse
# Create your views here.
class HomeView(View):
    def get(self,request,*args,**kwargs):
        return render(request,"main_home.html")
class LogView(View):
    def get(self,request,*args,**kwargs):
        f=LoginForm()
        return render(request,"log.html",{"form":f})
    def post(self,request,*args,**kwargs):
            return  HttpResponse("user_name:"+request.POST.get("user_name")+"<br>password:"+request.POST.get("password"))          
class RegView(View):   
    def get(self,request,*args,**kwargs):
        f=RegForm()
        return render(request,"reg.html",{"form":f})
    def post(self,request,*args,**kwargs): 
        return  HttpResponse("first_name:"+request.POST.get("first_name")+"<br>last_name:"+request.POST.get("last_name")+"<br>email:"+request.POST.get("email")+"<br>phone:"+request.POST.get("phone")+"<br>password:"+request.POST.get("password")+"<br>confirm_password:"+request.POST.get("confirm_password"))          
        