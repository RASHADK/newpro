from django.urls import path
from.views import Custhome
urlpatterns=[
    path('custh/',Custhome.as_view(),name="custhome")
]