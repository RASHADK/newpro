from django.urls import path
from.views import Storehome
urlpatterns=[
    path('storeh/',Storehome.as_view(),name="storehome")
]